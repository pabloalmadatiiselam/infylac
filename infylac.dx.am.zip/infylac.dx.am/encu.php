<!DOCTYPE html>
<html>
<head>
	<title>Enlace a formulario de Google</title>
</head>
<body>
	<a href="https://docs.google.com/forms/d/e/1FAIpQLSfSGzT__XI2zPQ6KdmapTE8VdHePsYBa_-OfKkLI9uL-o6EVw/viewform?usp=sf_link">Enlace al formulario</a>
</body>
</html>
